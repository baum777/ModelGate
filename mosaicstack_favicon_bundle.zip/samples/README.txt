ModelGate App Icon Bundle
=========================

Contents:
- originals/: full-size source PNGs for 4 icon variants
- favicon-bundle/: per-variant favicon/app-icon assets

Each variant folder contains:
- favicon-16x16.png
- favicon-32x32.png
- favicon-48x48.png
- icon-64x64.png
- icon-96x96.png
- apple-touch-icon.png (180x180)
- android-chrome-192x192.png
- android-chrome-512x512.png
- favicon.ico (multi-size ICO: 16/32/48)

Suggested usage:
- Pick one preferred variant and copy its favicon files into your web app public/assets folder.
- Use the 192x192 and 512x512 files for PWA manifest entries.
- Use apple-touch-icon.png for iOS homescreen.